<?php
 $conexion=mysqli_connect("localhost","root","","proyecto1") or die("problema de la conexion");

?>